from functools import wraps

from flask import redirect, session
from cs50 import SQL


db = SQL("sqlite:///project.db")


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)

    return decorated_function
